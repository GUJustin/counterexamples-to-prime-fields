#!/bin/sh
set -eu
s="$1"
t="$2"
mkdir -p out
venv/bin/python run_bounded.py --rss-mib 512 --seconds 90 --report "out/s${s}_t${t}.resources.json" -- venv/bin/python difference_set127.py --census multiplier_census.json --source-class "$s" --target-indices "$t" --h 95 --output "out/s${s}_t${t}.json" > "out/s${s}_t${t}.log" 2>&1
